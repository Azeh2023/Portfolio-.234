const welcomeText = document.getElementById('welcome');

welcomeText.addEventListener('mouseenter', addGlow);
welcomeText.addEventListener('mouseleave', removeGlow);

function addGlow() {
  welcomeText.classList.add('glow');
}

function removeGlow() {
  welcomeText.classList.remove('glow');
}